import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../state/app_state.dart';
import 'followups_screen.dart';
import 'operations_screen.dart';
import 'settings_screen.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s=AppStateScope.of(context);
    final items=<({IconData icon,String title,String subtitle,Widget screen})>[
      (icon:Icons.notifications_active_outlined,title:'Follow-ups',subtitle:'Today, overdue and upcoming tasks',screen:const FollowUpsScreen()),
      (icon:Icons.auto_awesome_outlined,title:'Smart Matching',subtitle:'Buyer requirements vs available inventory',screen:const MatchingScreen()),
      (icon:Icons.location_on_outlined,title:'Site Visits',subtitle:'Schedule visits and record feedback',screen:const VisitsScreen()),
      (icon:Icons.handshake_outlined,title:'Deals & Commission',subtitle:'Token, closing stages and commission balances',screen:const DealsScreen()),
      (icon:Icons.apartment_outlined,title:'Societies & Market Rates',subtitle:'B-17, FMC, Faisal Hills and your rate history',screen:const SocietiesScreen()),
      (icon:Icons.verified_user_outlined,title:'Property Verification',subtitle:'Ownership, documents, NOC and possession checks',screen:const VerificationScreen()),
      (icon:Icons.bar_chart_outlined,title:'Analytics',subtitle:'Inventory, pipeline and financial overview',screen:const AnalyticsScreen()),
      (icon:Icons.settings_outlined,title:'Settings',subtitle:'Profile, appearance, backup and archive management',screen:const SettingsScreen()),
    ];
    return ListView(padding:const EdgeInsets.fromLTRB(16,8,16,30),children:[
      Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:EstatePilotTheme.surface,borderRadius:BorderRadius.circular(20),border:Border.all(color:EstatePilotTheme.gold.withValues(alpha:.28))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('MORE',style:TextStyle(color:EstatePilotTheme.gold,fontSize:11,fontWeight:FontWeight.w900,letterSpacing:1.7)),
        const SizedBox(height:7),
        Text('EstatePilot Operations',style:Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.w900)),
        const SizedBox(height:5),
        Text('${s.pendingFollowUps} pending follow-ups • ${s.upcomingSiteVisits} upcoming visits • ${s.pendingCommission>0?'Commission pending':'Commission clear'}',style:const TextStyle(color:EstatePilotTheme.textSecondary,fontSize:12)),
      ])),
      const SizedBox(height:14),
      ...items.map((item)=>Padding(padding:const EdgeInsets.only(bottom:9),child:Container(decoration:BoxDecoration(color:EstatePilotTheme.surface,borderRadius:BorderRadius.circular(16),border:Border.all(color:EstatePilotTheme.divider)),child:ListTile(
        contentPadding:const EdgeInsets.symmetric(horizontal:14,vertical:6),
        leading:Container(width:40,height:40,decoration:BoxDecoration(color:EstatePilotTheme.gold.withValues(alpha:.09),borderRadius:BorderRadius.circular(12)),child:Icon(item.icon,color:EstatePilotTheme.gold,size:21)),
        title:Text(item.title,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:13.5)),
        subtitle:Text(item.subtitle,style:const TextStyle(color:EstatePilotTheme.textSecondary,fontSize:11.2)),
        trailing:const Icon(Icons.chevron_right,size:20),
        onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>item.screen)),
      )))),
    ]);
  }
}
