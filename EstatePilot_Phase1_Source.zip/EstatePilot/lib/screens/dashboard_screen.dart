import 'package:flutter/material.dart';

import '../core/formatters.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import 'client_form_screen.dart';
import 'followup_form_screen.dart';
import 'lead_form_screen.dart';
import 'operations_screen.dart';
import 'property_form_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key, required this.onNavigate});
  final ValueChanged<int> onNavigate;

  Future<void> _push(BuildContext context, Widget page) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => page));

  @override
  Widget build(BuildContext context) {
    final s = AppStateScope.of(context);
    final width = MediaQuery.sizeOf(context).width;
    final columns = width >= 700 ? 4 : 2;
    final metrics = <({String label,String value,IconData icon,bool highlight})>[
      (label:'Total Properties',value:'${s.totalProperties}',icon:Icons.apartment_outlined,highlight:true),
      (label:'Available',value:'${s.countPropertyStatus('Available')}',icon:Icons.check_circle_outline,highlight:false),
      (label:'Active Leads',value:'${s.activeLeads}',icon:Icons.filter_alt_outlined,highlight:false),
      (label:'Total Clients',value:'${s.clients.length}',icon:Icons.groups_outlined,highlight:false),
      (label:'Upcoming Visits',value:'${s.upcomingSiteVisits}',icon:Icons.event_outlined,highlight:false),
      (label:'Pending Follow-ups',value:'${s.pendingFollowUps}',icon:Icons.notifications_active_outlined,highlight:false),
      (label:'Active Deals',value:'${s.deals.where((d)=>d.status!='Completed'&&d.status!='Cancelled').length}',icon:Icons.handshake_outlined,highlight:false),
      (label:'Closed Deals',value:'${s.completedDeals}',icon:Icons.task_alt_outlined,highlight:false),
      (label:'Commission Received',value:formatPkr(s.totalCommission-s.pendingCommission),icon:Icons.account_balance_wallet_outlined,highlight:false),
      (label:'Commission Pending',value:formatPkr(s.pendingCommission),icon:Icons.pending_actions_outlined,highlight:false),
    ];
    final latest=[...s.properties]..sort((a,b)=>b.createdAt.compareTo(a.createdAt));
    final visits=[...s.siteVisits.where((v)=>v.status=='Scheduled')]..sort((a,b)=>a.scheduledAt.compareTo(b.scheduledAt));

    return ListView(padding:const EdgeInsets.fromLTRB(16,8,16,28),children:[
      _hero(context,s),
      const SizedBox(height:20),
      const SectionTitle('Business overview'),
      const SizedBox(height:10),
      GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),itemCount:metrics.length,
        gridDelegate:SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:columns,crossAxisSpacing:10,mainAxisSpacing:10,mainAxisExtent:136),
        itemBuilder:(context,i){final m=metrics[i];return MetricCard(label:m.label,value:m.value,icon:m.icon,highlight:m.highlight);}),
      const SizedBox(height:22),
      const SectionTitle('Quick actions'),const SizedBox(height:10),
      GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:3,crossAxisSpacing:9,mainAxisSpacing:9,childAspectRatio:1.18,children:[
        _quick(context,Icons.add_home_work_outlined,'Add Property',()=>_push(context,const PropertyFormScreen())),
        _quick(context,Icons.person_add_alt_1_outlined,'Add Client',()=>_push(context,const ClientFormScreen())),
        _quick(context,Icons.add_chart_outlined,'Add Lead',()=>_push(context,const LeadFormScreen())),
        _quick(context,Icons.event_available_outlined,'Schedule Visit',()=>_push(context,const VisitForm())),
        _quick(context,Icons.notification_add_outlined,'Follow-up',()=>_push(context,const FollowUpFormScreen())),
        _quick(context,Icons.handshake_outlined,'Add Deal',()=>_push(context,const DealForm())),
      ]),
      const SizedBox(height:22),
      SectionTitle('Today & overdue',trailing:TextButton(onPressed:()=>onNavigate(4),child:const Text('More'))),
      const SizedBox(height:10),
      if(s.todayFollowUps.isEmpty&&s.overdueFollowUps.isEmpty)
        const _Compact(icon:Icons.task_alt_outlined,title:'No urgent follow-ups',text:'Today and overdue follow-ups will appear here.')
      else ...[
        ...s.overdueFollowUps.take(3).map((f)=>_followUp(f,true)),
        ...s.todayFollowUps.take(4).map((f)=>_followUp(f,false)),
      ],
      const SizedBox(height:22),
      const SectionTitle('Upcoming site visits'),const SizedBox(height:10),
      if(visits.isEmpty)const _Compact(icon:Icons.event_outlined,title:'No scheduled visits',text:'Site visits you schedule will appear here.')
      else ...visits.take(4).map((v){
        final c=s.clientById(v.clientId),p=s.propertyById(v.propertyId);
        return _listTile(icon:Icons.location_on_outlined,title:c?.name??'Client',subtitle:'${p?.displayLocation??'Property'} • ${formatDate(v.scheduledAt)} ${formatTime(v.scheduledAt)}');
      }),
      const SizedBox(height:22),
      const SectionTitle('Latest properties'),const SizedBox(height:10),
      if(latest.isEmpty)const _Compact(icon:Icons.home_work_outlined,title:'Inventory is empty',text:'Add your first property with source, reference and media.')
      else ...latest.where((p)=>p.status!='Archived').take(4).map((p)=>_listTile(icon:Icons.home_work_outlined,title:'${p.propertyId} • ${p.size} ${p.unit}',subtitle:'${p.displayLocation} • ${formatPkr(p.displayPrice)} • ${p.status}')),
      const SizedBox(height:22),
      const SectionTitle('Recent activity'),const SizedBox(height:10),
      if(s.activities.isEmpty)const _Compact(icon:Icons.history_outlined,title:'No activity yet',text:'Changes across CRM modules will be recorded here.')
      else ...s.activities.take(7).map((a)=>_listTile(icon:_activityIcon(a.kind),title:a.title,subtitle:'${a.subtitle} • ${formatDate(a.createdAt)} ${formatTime(a.createdAt)}')),
    ]);
  }

  Widget _hero(BuildContext context,AppState s){
    final now=DateTime.now();
    final name=s.settings.profileName.trim().isEmpty?'Property Manager':s.settings.profileName.trim();
    const months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    return Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:EstatePilotTheme.surface,borderRadius:BorderRadius.circular(24),border:Border.all(color:EstatePilotTheme.gold.withValues(alpha:.30))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[
        Container(width:46,height:46,decoration:BoxDecoration(color:EstatePilotTheme.deepBrown,borderRadius:BorderRadius.circular(14),border:Border.all(color:EstatePilotTheme.gold.withValues(alpha:.35))),child:const Icon(Icons.domain_outlined,color:EstatePilotTheme.gold)),
        const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('ESTATEPILOT',style:TextStyle(color:EstatePilotTheme.lightGold,fontWeight:FontWeight.w900,letterSpacing:1.8,fontSize:12)),
          const SizedBox(height:3),Text('Welcome, $name',style:Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.w900)),
        ])),
      ]),
      const SizedBox(height:16),
      Text('${now.day} ${months[now.month-1]} ${now.year}',style:const TextStyle(color:EstatePilotTheme.textSecondary,fontSize:12)),
      const SizedBox(height:6),
      const Text('Your real-estate office at a glance.',style:TextStyle(color:EstatePilotTheme.textSecondary)),
      const SizedBox(height:16),
      Row(children:[
        _heroStat('Inventory','${s.totalProperties}'),const SizedBox(width:10),_heroStat('Clients','${s.clients.length}'),const SizedBox(width:10),_heroStat('Pending',formatPkr(s.pendingCommission)),
      ]),
    ]));
  }

  Widget _heroStat(String label,String value)=>Expanded(child:Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:EstatePilotTheme.secondaryBackground,borderRadius:BorderRadius.circular(14),border:Border.all(color:EstatePilotTheme.divider)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(value,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(color:EstatePilotTheme.lightGold,fontWeight:FontWeight.w900,fontSize:16)),const SizedBox(height:2),Text(label,style:const TextStyle(color:EstatePilotTheme.textSecondary,fontSize:10.5))])));

  Widget _quick(BuildContext context,IconData icon,String label,VoidCallback onTap)=>InkWell(onTap:onTap,borderRadius:BorderRadius.circular(16),child:Container(padding:const EdgeInsets.symmetric(horizontal:8,vertical:13),decoration:BoxDecoration(color:EstatePilotTheme.surface,borderRadius:BorderRadius.circular(16),border:Border.all(color:EstatePilotTheme.divider)),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(icon,color:EstatePilotTheme.gold,size:22),const SizedBox(height:7),Text(label,textAlign:TextAlign.center,style:const TextStyle(fontSize:11,fontWeight:FontWeight.w700))])));

  Widget _followUp(FollowUpModel f,bool overdue)=>_listTile(icon:overdue?Icons.error_outline:Icons.schedule_outlined,title:f.contactName.isEmpty?f.title:f.contactName,subtitle:'${f.title} • ${formatTime(f.scheduledAt)}${overdue?' • OVERDUE':''}',danger:overdue);

  Widget _listTile({required IconData icon,required String title,required String subtitle,bool danger=false})=>Container(margin:const EdgeInsets.only(bottom:8),decoration:BoxDecoration(color:EstatePilotTheme.surface,borderRadius:BorderRadius.circular(15),border:Border.all(color:EstatePilotTheme.divider)),child:ListTile(dense:true,leading:Icon(icon,color:danger?EstatePilotTheme.error:EstatePilotTheme.gold),title:Text(title,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:13)),subtitle:Text(subtitle,maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(color:EstatePilotTheme.textSecondary,fontSize:11.5))));

  IconData _activityIcon(String kind)=>switch(kind){'property'=>Icons.home_work_outlined,'client'=>Icons.person_outline,'lead'=>Icons.filter_alt_outlined,'deal'=>Icons.handshake_outlined,'visit'=>Icons.location_on_outlined,'followup'=>Icons.notifications_active_outlined,_=>Icons.history_outlined};
}

class _Compact extends StatelessWidget {
  const _Compact({required this.icon,required this.title,required this.text});
  final IconData icon;final String title,text;
  @override Widget build(BuildContext context)=>LuxuryPanel(child:Row(children:[Container(width:42,height:42,decoration:BoxDecoration(color:EstatePilotTheme.gold.withValues(alpha:.10),borderRadius:BorderRadius.circular(13)),child:Icon(icon,color:EstatePilotTheme.gold)),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontWeight:FontWeight.w800)),const SizedBox(height:3),Text(text,style:const TextStyle(color:EstatePilotTheme.textSecondary,fontSize:11.5))]))]));
}
