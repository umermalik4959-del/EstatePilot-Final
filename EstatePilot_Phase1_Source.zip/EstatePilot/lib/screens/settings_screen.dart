import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import 'operations_screen.dart';
import 'property_detail_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final settings = state.settings;
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 36),
        children: [
          _header(context, settings),
          const SizedBox(height: 18),
          _group(context, 'ACCOUNT', [
            _row(Icons.person_outline, 'My Profile',
                settings.profileName.isEmpty ? 'Add your name and contact information' : settings.profileName,
                () => _editProfile(context, state, settings)),
          ]),
          _group(context, 'APP PREFERENCES', [
            _row(Icons.palette_outlined, 'Appearance',
                settings.themeMode == 'light' ? 'Warm light theme' : 'Luxury dark theme',
                () => _appearance(context, state, settings)),
            _row(Icons.currency_rupee, 'Currency', 'PKR • stored values remain numeric', null),
            _row(Icons.apartment_outlined, 'Default Society', settings.defaultSociety,
                () => _defaultSociety(context, state, settings)),
          ]),
          _group(context, 'DATA MANAGEMENT', [
            _row(Icons.backup_outlined, 'Backup / Restore', 'Export or restore your private CRM data',
                () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BackupScreen()))),
            _row(Icons.storage_outlined, 'Storage Summary',
                '${state.properties.length} properties • ${state.clients.length} clients • ${state.deals.length} deals',
                () => _storageSummary(context, state)),
            _row(Icons.archive_outlined, 'Archive Management',
                '${state.properties.where((p) => p.status == 'Archived').length} archived properties',
                () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ArchiveManagementScreen()))),
          ]),
          _group(context, 'APP INFORMATION', [
            _row(Icons.info_outline, 'About EstatePilot', 'Professional offline-first real-estate CRM',
                () => showAboutDialog(
                      context: context,
                      applicationName: 'EstatePilot',
                      applicationVersion: '3.0.0',
                      applicationLegalese: 'Local-first real estate CRM. Your business data stays on the device unless you export it.',
                    )),
            _row(Icons.privacy_tip_outlined, 'Privacy / Data',
                'No cloud sync is enabled in this build',
                () => showDialog<void>(context: context, builder: (_) => const AlertDialog(
                      title: Text('Data privacy'),
                      content: Text('EstatePilot stores CRM records locally in app-private Android storage. Data leaves the app only when you explicitly export/share it.'),
                    ))),
          ]),
        ],
      ),
    );
  }

  Widget _header(BuildContext context, AppSettingsModel s) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: EstatePilotTheme.surface,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: EstatePilotTheme.gold.withValues(alpha: .28)),
        ),
        child: Row(children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(color: EstatePilotTheme.deepBrown, borderRadius: BorderRadius.circular(16)),
            child: const Icon(Icons.person_outline, color: EstatePilotTheme.gold, size: 28),
          ),
          const SizedBox(width: 13),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Settings', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 3),
            const Text('Manage your EstatePilot experience', style: TextStyle(color: EstatePilotTheme.textSecondary)),
            if (s.profileName.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(s.profileName, style: const TextStyle(color: EstatePilotTheme.lightGold, fontWeight: FontWeight.w800)),
            ],
          ])),
        ]),
      );

  Widget _group(BuildContext context, String title, List<Widget> rows) => Padding(
        padding: const EdgeInsets.only(bottom: 18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 0, 4, 8),
            child: Text(title, style: const TextStyle(color: EstatePilotTheme.gold, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.25)),
          ),
          Container(
            decoration: BoxDecoration(color: EstatePilotTheme.surface, borderRadius: BorderRadius.circular(18), border: Border.all(color: EstatePilotTheme.divider)),
            child: Column(children: [
              for (var i = 0; i < rows.length; i++) ...[
                rows[i],
                if (i != rows.length - 1) const Divider(height: 1, indent: 58),
              ],
            ]),
          ),
        ]),
      );

  Widget _row(IconData icon, String title, String subtitle, VoidCallback? onTap) => ListTile(
        onTap: onTap,
        leading: Container(width: 36, height: 36, decoration: BoxDecoration(color: EstatePilotTheme.gold.withValues(alpha: .09), borderRadius: BorderRadius.circular(11)), child: Icon(icon, color: EstatePilotTheme.gold, size: 19)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5)),
        subtitle: Text(subtitle, style: const TextStyle(color: EstatePilotTheme.textSecondary, fontSize: 11.5)),
        trailing: onTap == null ? null : const Icon(Icons.chevron_right, size: 20),
      );

  Future<void> _editProfile(BuildContext context, AppState state, AppSettingsModel settings) async {
    final name = TextEditingController(text: settings.profileName);
    final phone = TextEditingController(text: settings.profilePhone);
    final ok = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
          title: const Text('My Profile'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Name')),
            const SizedBox(height: 10),
            TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Phone')),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Save')),
          ],
        ));
    if (ok == true) await state.updateSettings(settings.copyWith(profileName: name.text.trim(), profilePhone: phone.text.trim()));
    name.dispose(); phone.dispose();
  }

  Future<void> _appearance(BuildContext context, AppState state, AppSettingsModel settings) async {
    final result = await showModalBottomSheet<String>(context: context, showDragHandle: true, builder: (context) => SafeArea(child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const ListTile(title: Text('EstatePilot Appearance'), subtitle: Text('Both options preserve black/brown/gold brand colors.')),
            RadioListTile(value: 'dark', groupValue: settings.themeMode, onChanged: (v) => Navigator.pop(context, v), title: const Text('Luxury Dark'), subtitle: const Text('Recommended')), 
            RadioListTile(value: 'light', groupValue: settings.themeMode, onChanged: (v) => Navigator.pop(context, v), title: const Text('Warm Light')),
          ],
        ))));
    if (result != null) await state.updateSettings(settings.copyWith(themeMode: result));
  }

  Future<void> _defaultSociety(BuildContext context, AppState state, AppSettingsModel settings) async {
    final choices = <String>{'B-17', 'FMC', 'Faisal Hills', ...state.societies.map((e) => e.name)}.toList();
    final result = await showModalBottomSheet<String>(context: context, showDragHandle: true, builder: (context) => SafeArea(child: ListView(
          shrinkWrap: true,
          children: choices.map((e) => RadioListTile<String>(value: e, groupValue: settings.defaultSociety, title: Text(e), onChanged: (v) => Navigator.pop(context, v))).toList(),
        )));
    if (result != null) await state.updateSettings(settings.copyWith(defaultSociety: result));
  }

  Future<void> _storageSummary(BuildContext context, AppState state) => showDialog<void>(context: context, builder: (_) => AlertDialog(
        title: const Text('Storage Summary'),
        content: Text('Properties: ${state.properties.length}\nClients: ${state.clients.length}\nLeads: ${state.leads.length}\nFollow-ups: ${state.followUps.length}\nSite visits: ${state.siteVisits.length}\nDeals: ${state.deals.length}\nSocieties: ${state.societies.length}\n\nProperty photos, videos and documents are copied into EstatePilot app-private storage.'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
      ));
}

class ArchiveManagementScreen extends StatelessWidget {
  const ArchiveManagementScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final archived = state.properties.where((p) => p.status == 'Archived').toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Archive Management')),
      body: archived.isEmpty
          ? const EmptyState(icon: Icons.archive_outlined, title: 'Archive is empty', message: 'Archived properties remain available here for future reference.')
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: archived.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, i) {
                final p = archived[i];
                return Card(child: ListTile(
                  title: Text('${p.propertyId} • ${p.size} ${p.unit}', style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text(p.displayLocation, style: const TextStyle(color: EstatePilotTheme.textSecondary)),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PropertyDetailScreen(propertyId: p.id))),
                  trailing: TextButton(onPressed: () => state.restoreArchivedProperty(p.id), child: const Text('Restore')),
                ));
              },
            ),
    );
  }
}
