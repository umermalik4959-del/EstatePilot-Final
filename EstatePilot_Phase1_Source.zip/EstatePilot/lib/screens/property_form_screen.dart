import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

import '../core/media_store.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../state/app_state.dart';

class PropertyFormScreen extends StatefulWidget {
  const PropertyFormScreen({super.key, this.initial});
  final PropertyModel? initial;

  @override
  State<PropertyFormScreen> createState() => _PropertyFormScreenState();
}

class _PropertyFormScreenState extends State<PropertyFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final String _recordId;
  late final TextEditingController _propertyId;
  late final TextEditingController _referenceNo;
  late final TextEditingController _block;
  late final TextEditingController _sector;
  late final TextEditingController _street;
  late final TextEditingController _plot;
  late final TextEditingController _size;
  late final TextEditingController _roadWidth;
  late final TextEditingController _facing;
  late final TextEditingController _ownerDemand;
  late final TextEditingController _askingPrice;
  late final TextEditingController _expectedPrice;
  late final TextEditingController _minimumPrice;
  late final TextEditingController _salePrice;
  late final TextEditingController _commission;
  late final TextEditingController _tokenAmount;
  late final TextEditingController _remainingAmount;
  late final TextEditingController _paymentTerms;
  late final TextEditingController _ownerName;
  late final TextEditingController _ownerPhone;
  late final TextEditingController _sourceContact;
  late final TextEditingController _sourceDetail;
  late final TextEditingController _locationNotes;
  late final TextEditingController _notes;

  String _society = 'B-17';
  String _type = 'Residential Plot';
  String _unit = 'Marla';
  String _purpose = 'Sale';
  String _status = 'Available';
  String _source = 'Owner Direct';
  bool _corner = false;
  bool _parkFacing = false;
  bool _mainRoad = false;
  bool _possession = false;
  bool _electricity = false;
  bool _gas = false;
  bool _water = false;
  bool _sewerage = false;
  bool _negotiable = false;
  bool _urgentSale = false;
  bool _installmentAvailable = false;
  bool _saving = false;
  bool _pickingMedia = false;
  bool _defaultsLoaded = false;
  final List<String> _images = [];
  final List<String> _videos = [];
  final List<String> _documents = [];

  bool get _editing => widget.initial != null;

  @override
  void initState() {
    super.initState();
    final p0 = widget.initial;
    _recordId = p0?.id ?? newId('P');
    _propertyId = TextEditingController(text: p0?.propertyId ?? '');
    _referenceNo = TextEditingController(text: p0?.referenceNo ?? '');
    _block = TextEditingController(text: p0?.block ?? '');
    _sector = TextEditingController(text: p0?.sector ?? '');
    _street = TextEditingController(text: p0?.street ?? '');
    _plot = TextEditingController(text: p0?.plotNumber ?? '');
    _size = TextEditingController(text: p0?.size ?? '');
    _roadWidth = TextEditingController(text: p0?.roadWidth ?? '');
    _facing = TextEditingController(text: p0?.facing ?? '');
    _ownerDemand = TextEditingController(text: _moneyText(p0?.ownerDemand));
    _askingPrice = TextEditingController(text: _moneyText(p0?.askingPrice));
    _expectedPrice = TextEditingController(text: _moneyText(p0?.expectedDealPrice));
    _minimumPrice = TextEditingController(text: _moneyText(p0?.minimumPrice));
    _salePrice = TextEditingController(text: _moneyText(p0?.salePrice));
    _commission = TextEditingController(text: _moneyText(p0?.commission));
    _tokenAmount = TextEditingController(text: _moneyText(p0?.tokenAmount));
    _remainingAmount = TextEditingController(text: _moneyText(p0?.remainingAmount));
    _paymentTerms = TextEditingController(text: p0?.paymentTerms ?? '');
    _ownerName = TextEditingController(text: p0?.ownerName ?? '');
    _ownerPhone = TextEditingController(text: p0?.ownerPhone ?? '');
    _sourceContact = TextEditingController(text: p0?.sourceContact ?? '');
    _sourceDetail = TextEditingController(text: p0?.sourceDetail ?? '');
    _locationNotes = TextEditingController(text: p0?.locationNotes ?? '');
    _notes = TextEditingController(text: p0?.notes ?? '');
    if (p0 != null) {
      _society = p0.society.isEmpty ? 'B-17' : p0.society;
      _type = p0.type;
      _unit = p0.unit;
      _purpose = p0.purpose;
      _status = p0.status;
      _source = p0.source;
      _corner = p0.corner;
      _parkFacing = p0.parkFacing;
      _mainRoad = p0.mainRoad;
      _possession = p0.possession;
      _electricity = p0.electricity;
      _gas = p0.gas;
      _water = p0.water;
      _sewerage = p0.sewerage;
      _negotiable = p0.negotiable;
      _urgentSale = p0.urgentSale;
      _installmentAvailable = p0.installmentAvailable;
      _images.addAll(p0.imagePaths);
      _videos.addAll(p0.videoPaths);
      _documents.addAll(p0.documentPaths);
    }
  }


  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_defaultsLoaded) return;
    _defaultsLoaded = true;
    if (widget.initial == null) {
      final preferred = AppStateScope.of(context).settings.defaultSociety;
      if (preferred.trim().isNotEmpty) _society = preferred;
    }
  }

  String _moneyText(double? value) => value == null || value == 0 ? '' : value.toStringAsFixed(0);

  @override
  void dispose() {
    for (final c in [
      _propertyId,_referenceNo,_block,_sector,_street,_plot,_size,_roadWidth,_facing,
      _ownerDemand,_askingPrice,_expectedPrice,_minimumPrice,_salePrice,_commission,
      _tokenAmount,_remainingAmount,_paymentTerms,_ownerName,_ownerPhone,_sourceContact,
      _sourceDetail,_locationNotes,_notes,
    ]) { c.dispose(); }
    super.dispose();
  }

  double _money(TextEditingController c) =>
      double.tryParse(c.text.replaceAll(',', '').trim()) ?? 0;

  String _autoPropertyId(AppState state) {
    var serial = state.properties.length + 1;
    while (state.properties.any((item) =>
        item.propertyId == 'EP-${serial.toString().padLeft(4, '0')}')) { serial++; }
    return 'EP-${serial.toString().padLeft(4, '0')}';
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    final state = AppStateScope.of(context);
    final now = DateTime.now();
    final sale = _money(_salePrice);
    final token = _money(_tokenAmount);
    final calculatedRemaining = sale > 0 ? (sale - token).clamp(0, double.infinity).toDouble() : 0.0;
    final propertyId = _propertyId.text.trim().isEmpty ? _autoPropertyId(state) : _propertyId.text.trim();
    final referenceNo = _referenceNo.text.trim().isEmpty ? propertyId : _referenceNo.text.trim();
    final model = PropertyModel(
      id: _recordId,
      propertyId: propertyId,
      referenceNo: referenceNo,
      society: _society,
      block: _block.text.trim(),
      sector: _sector.text.trim(),
      street: _street.text.trim(),
      plotNumber: _plot.text.trim(),
      type: _type,
      size: _size.text.trim(),
      unit: _unit,
      purpose: _purpose,
      status: _status,
      ownerDemand: _money(_ownerDemand),
      askingPrice: _money(_askingPrice),
      expectedDealPrice: _money(_expectedPrice),
      minimumPrice: _money(_minimumPrice),
      salePrice: sale,
      commission: _money(_commission),
      tokenAmount: token,
      remainingAmount: _money(_remainingAmount) > 0 ? _money(_remainingAmount) : calculatedRemaining,
      paymentTerms: _paymentTerms.text.trim(),
      installmentAvailable: _installmentAvailable,
      ownerName: _ownerName.text.trim(),
      ownerPhone: _ownerPhone.text.trim(),
      source: _source,
      sourceContact: _sourceContact.text.trim(),
      sourceDetail: _sourceDetail.text.trim(),
      roadWidth: _roadWidth.text.trim(),
      facing: _facing.text.trim(),
      locationNotes: _locationNotes.text.trim(),
      notes: _notes.text.trim(),
      corner: _corner,
      parkFacing: _parkFacing,
      mainRoad: _mainRoad,
      possession: _possession,
      electricity: _electricity,
      gas: _gas,
      water: _water,
      sewerage: _sewerage,
      negotiable: _negotiable,
      urgentSale: _urgentSale,
      imagePaths: List.unmodifiable(_images),
      videoPaths: List.unmodifiable(_videos),
      documentPaths: List.unmodifiable(_documents),
      history: widget.initial?.history ?? ['${now.toIso8601String()} | Property created'],
      soldAt: _status == 'Sold' ? (widget.initial?.soldAt ?? now) : null,
      createdAt: widget.initial?.createdAt ?? now,
      updatedAt: now,
    );
    try {
      if (_editing) { await state.updateProperty(model); } else { await state.addProperty(model); }
      if (mounted) Navigator.pop(context, model);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Unable to save property: $e')));
      setState(() => _saving = false);
    }
  }

  Future<void> _runMedia(Future<void> Function() action) async {
    if (_pickingMedia) return;
    setState(() => _pickingMedia = true);
    try { await action(); }
    catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Attachment error: $e')));
    } finally { if (mounted) setState(() => _pickingMedia = false); }
  }

  Future<void> _addGalleryImages() => _runMedia(() async {
    final items = await MediaStore.pickImages(_recordId);
    if (mounted) setState(() => _images.addAll(items));
  });

  Future<void> _takePhoto() => _runMedia(() async {
    final item = await MediaStore.takePhoto(_recordId);
    if (item != null && mounted) setState(() => _images.add(item));
  });

  Future<void> _pickVideo() => _runMedia(() async {
    final item = await MediaStore.pickVideo(_recordId);
    if (item != null && mounted) setState(() => _videos.add(item));
  });

  Future<void> _recordVideo() => _runMedia(() async {
    final item = await MediaStore.recordVideo(_recordId);
    if (item != null && mounted) setState(() => _videos.add(item));
  });

  Future<void> _pickDocuments() => _runMedia(() async {
    final items = await MediaStore.pickDocuments(_recordId);
    if (mounted) setState(() => _documents.addAll(items));
  });

  Future<void> _removeStored(List<String> list, int index) async {
    final path = list[index];
    setState(() => list.removeAt(index));
    await MediaStore.deleteStoredFile(path);
  }

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final societies = <String>{'B-17','FMC','Faisal Hills',...state.societies.map((e)=>e.name),_society}.toList();
    return Scaffold(
      appBar: AppBar(title: Text(_editing ? 'Edit Property' : 'Add Property')),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        child: FilledButton.icon(
          onPressed: _saving ? null : _save,
          icon: _saving
              ? const SizedBox(width: 18,height:18,child:CircularProgressIndicator(strokeWidth:2))
              : const Icon(Icons.save_outlined),
          label: Text(_editing ? 'Save Changes' : 'Save Property'),
        ),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
          children: [
            _section('Property Information', Icons.home_work_outlined, [
              Row(children:[
                Expanded(child:_text(_propertyId,'Property ID',hint:'Auto if blank')),
                const SizedBox(width:10),
                Expanded(child:_text(_referenceNo,'Reference No.',hint:'File / diary ref')),
              ]),
              _dropdown('Society',_society,societies,(v)=>setState(()=>_society=v)),
              Row(children:[
                Expanded(child:_text(_block,'Block',required:true)),
                const SizedBox(width:10),
                Expanded(child:_text(_sector,'Sector')),
              ]),
              Row(children:[
                Expanded(child:_text(_street,'Street')),
                const SizedBox(width:10),
                Expanded(child:_text(_plot,'Plot Number')),
              ]),
              _dropdown('Property Type',_type,const [
                'Residential Plot','Commercial Plot','House','Apartment','Farmhouse','Shop','Office','Commercial Property','Other'
              ],(v)=>setState(()=>_type=v)),
              Row(children:[
                Expanded(child:_text(_size,'Size',required:true,keyboard:TextInputType.number)),
                const SizedBox(width:10),
                Expanded(child:_dropdown('Unit',_unit,const ['Marla','Kanal','Sq Ft','Sq Yd','Other'],(v)=>setState(()=>_unit=v))),
              ]),
              Row(children:[
                Expanded(child:_dropdown('Purpose',_purpose,const ['Sale','Rent'],(v)=>setState(()=>_purpose=v))),
                const SizedBox(width:10),
                Expanded(child:_dropdown('Status',_status,const ['Available','Hold','Reserved','Sold','Rented','Unavailable','Archived'],(v)=>setState(()=>_status=v))),
              ]),
            ]),
            _section('Location & Features', Icons.pin_drop_outlined, [
              Row(children:[
                Expanded(child:_text(_roadWidth,'Road Width',hint:'40 ft')),
                const SizedBox(width:10),
                Expanded(child:_text(_facing,'Facing',hint:'North / South')),
              ]),
              _textArea(_locationNotes,'Location Notes','Near mosque, commercial, school, boulevard, access…',2,4),
              _switchGrid([
                ('Corner',_corner,(v)=>_corner=v),('Park Facing',_parkFacing,(v)=>_parkFacing=v),
                ('Main Road',_mainRoad,(v)=>_mainRoad=v),('Possession',_possession,(v)=>_possession=v),
              ]),
            ]),
            _section('Utilities', Icons.electrical_services_outlined, [
              _switchGrid([
                ('Electricity',_electricity,(v)=>_electricity=v),('Gas',_gas,(v)=>_gas=v),
                ('Water',_water,(v)=>_water=v),('Sewerage',_sewerage,(v)=>_sewerage=v),
              ]),
            ]),
            _section('Financial Information', Icons.account_balance_wallet_outlined, [
              _moneyField(_ownerDemand,'Owner Demand'),
              _moneyField(_askingPrice,'Asking Price'),
              _moneyField(_expectedPrice,'Expected Deal Price'),
              _moneyField(_minimumPrice,'Minimum Acceptable Price'),
              if (_status=='Sold') _moneyField(_salePrice,'Final Sale Price'),
              _moneyField(_commission,'Commission Amount'),
              _moneyField(_tokenAmount,'Token Amount'),
              _moneyField(_remainingAmount,'Remaining Amount'),
              _textArea(_paymentTerms,'Payment Terms','Cash / installment schedule / transfer notes…',2,4),
              _switchGrid([
                ('Installment Available',_installmentAvailable,(v)=>_installmentAvailable=v),
                ('Negotiable',_negotiable,(v)=>_negotiable=v),
                ('Urgent Sale',_urgentSale,(v)=>_urgentSale=v),
              ]),
              const Text('Owner Demand, Asking Price, Expected Deal Price and Sale Price are stored separately.',
                style:TextStyle(fontSize:11.5,color:EstatePilotTheme.textSecondary)),
            ]),
            _section('Owner & Source / Reference', Icons.person_pin_circle_outlined, [
              _text(_ownerName,'Owner Name'),
              _text(_ownerPhone,'Owner Phone',keyboard:TextInputType.phone),
              _dropdown('Property Source',_source,const ['Owner Direct','Dealer','Agency','Client','Referral','Facebook','WhatsApp','OLX','Other'],(v)=>setState(()=>_source=v)),
              _text(_sourceContact,'Source Contact / Dealer'),
              _textArea(_sourceDetail,'Source Detail','Where it came from, who referred it, deal context, file/reference trail…',2,5),
            ]),
            _mediaSection(),
            _section('Notes', Icons.sticky_note_2_outlined, [
              _textArea(_notes,'Internal Notes','Negotiation, urgency, client feedback, legal/document notes…',4,8),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _mediaSection() => _section('Photos, Videos & Documents', Icons.photo_library_outlined, [
    Wrap(spacing:8,runSpacing:8,children:[
      OutlinedButton.icon(onPressed:_pickingMedia?null:_addGalleryImages,icon:const Icon(Icons.photo_library_outlined),label:const Text('Add Photos')),
      OutlinedButton.icon(onPressed:_pickingMedia?null:_takePhoto,icon:const Icon(Icons.camera_alt_outlined),label:const Text('Camera')),
      OutlinedButton.icon(onPressed:_pickingMedia?null:_pickVideo,icon:const Icon(Icons.video_library_outlined),label:const Text('Add Video')),
      OutlinedButton.icon(onPressed:_pickingMedia?null:_recordVideo,icon:const Icon(Icons.videocam_outlined),label:const Text('Record Video')),
      OutlinedButton.icon(onPressed:_pickingMedia?null:_pickDocuments,icon:const Icon(Icons.attach_file_outlined),label:const Text('Documents')),
    ]),
    if(_pickingMedia) const LinearProgressIndicator(minHeight:2),
    if(_images.isNotEmpty) ...[
      const Text('Photos',style:TextStyle(fontWeight:FontWeight.w800)),
      SizedBox(height:96,child:ListView.separated(scrollDirection:Axis.horizontal,itemCount:_images.length,separatorBuilder:(_,__)=>const SizedBox(width:8),itemBuilder:(context,i){
        final file=File(_images[i]);
        return Stack(children:[
          ClipRRect(borderRadius:BorderRadius.circular(12),child:Container(width:110,color:EstatePilotTheme.secondaryBackground,child:file.existsSync()?Image.file(file,fit:BoxFit.cover):const Icon(Icons.broken_image_outlined))),
          Positioned(right:2,top:2,child:IconButton.filledTonal(iconSize:16,onPressed:()=>_removeStored(_images,i),icon:const Icon(Icons.close))),
        ]);
      })),
    ],
    if(_videos.isNotEmpty) ...[
      const Text('Videos',style:TextStyle(fontWeight:FontWeight.w800)),
      ...List.generate(_videos.length,(i)=>_attachmentRow(Icons.videocam_outlined,_videos[i],()=>_removeStored(_videos,i))),
    ],
    if(_documents.isNotEmpty) ...[
      const Text('Documents',style:TextStyle(fontWeight:FontWeight.w800)),
      ...List.generate(_documents.length,(i)=>_attachmentRow(Icons.description_outlined,_documents[i],()=>_removeStored(_documents,i))),
    ],
  ]);

  Widget _attachmentRow(IconData icon,String path,VoidCallback remove)=>Container(
    margin:const EdgeInsets.only(top:6),padding:const EdgeInsets.symmetric(horizontal:10,vertical:8),
    decoration:BoxDecoration(color:EstatePilotTheme.secondaryBackground,borderRadius:BorderRadius.circular(12),border:Border.all(color:EstatePilotTheme.divider)),
    child:Row(children:[Icon(icon,size:18,color:EstatePilotTheme.gold),const SizedBox(width:8),Expanded(child:Text(p.basename(path),maxLines:1,overflow:TextOverflow.ellipsis)),IconButton(onPressed:remove,icon:const Icon(Icons.close,size:18))]));

  Widget _section(String title,IconData icon,List<Widget> children)=>Card(
    margin:const EdgeInsets.only(bottom:14),child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[Icon(icon,color:EstatePilotTheme.gold,size:20),const SizedBox(width:8),Text(title,style:Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight:FontWeight.w900))]),
      const SizedBox(height:14),
      for(var i=0;i<children.length;i++)...[children[i],if(i!=children.length-1)const SizedBox(height:10)],
    ])));

  Widget _text(TextEditingController c,String label,{String? hint,bool required=false,TextInputType? keyboard})=>TextFormField(
    controller:c,keyboardType:keyboard,validator:required?(v)=>(v==null||v.trim().isEmpty)?'$label is required':null:null,
    decoration:InputDecoration(labelText:label,hintText:hint));

  Widget _textArea(TextEditingController c,String label,String hint,int min,int max)=>TextFormField(
    controller:c,minLines:min,maxLines:max,decoration:InputDecoration(labelText:label,hintText:hint));

  Widget _moneyField(TextEditingController c,String label)=>TextFormField(
    controller:c,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:InputDecoration(labelText:label,prefixText:'Rs. '));

  Widget _dropdown(String label,String value,List<String> options,ValueChanged<String> onChanged){
    final list=<String>{...options,value}.toList();
    return DropdownButtonFormField<String>(initialValue:value,isExpanded:true,decoration:InputDecoration(labelText:label),
      items:list.map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v){if(v!=null)onChanged(v);});
  }

  Widget _switchGrid(List<(String,bool,ValueChanged<bool>)> items)=>LayoutBuilder(builder:(context,constraints){
    final width=(constraints.maxWidth-8)/2;
    return Wrap(spacing:8,runSpacing:8,children:items.map((item)=>SizedBox(width:items.length==1?constraints.maxWidth:width,child:InkWell(
      borderRadius:BorderRadius.circular(13),onTap:()=>setState(()=>item.$3(!item.$2)),child:Container(
        padding:const EdgeInsets.symmetric(horizontal:10,vertical:8),decoration:BoxDecoration(
          border:Border.all(color:item.$2?EstatePilotTheme.gold:EstatePilotTheme.divider),
          color:item.$2?EstatePilotTheme.gold.withValues(alpha:.07):EstatePilotTheme.secondaryBackground,
          borderRadius:BorderRadius.circular(13)),child:Row(children:[Expanded(child:Text(item.$1,style:const TextStyle(fontSize:12,fontWeight:FontWeight.w700))),Switch.adaptive(value:item.$2,onChanged:(v)=>setState(()=>item.$3(v)))]))))).toList());
  });
}
