import 'dart:io';

import 'package:flutter/material.dart';

import '../core/formatters.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import 'property_detail_screen.dart';
import 'property_form_screen.dart';

class PropertiesScreen extends StatefulWidget {
  const PropertiesScreen({super.key});
  @override State<PropertiesScreen> createState()=>_PropertiesScreenState();
}

class _PropertiesScreenState extends State<PropertiesScreen> {
  final _search=TextEditingController();
  String _society='All',_status='Active',_type='All',_sort='Newest';
  @override void dispose(){_search.dispose();super.dispose();}

  List<PropertyModel> _filtered(AppState s){
    var list=s.searchProperties(_search.text).where((p){
      if(_status=='Active' && ['Sold','Rented','Archived','Unavailable'].contains(p.status)) return false;
      if(_status=='Sold' && p.status!='Sold') return false;
      if(_status=='Archived' && p.status!='Archived') return false;
      if(!['Active','Sold','Archived','All'].contains(_status) && p.status!=_status)return false;
      if(_society!='All' && p.society!=_society)return false;
      if(_type!='All' && p.type!=_type)return false;
      return true;
    }).toList();
    switch(_sort){
      case 'Price Low': list.sort((a,b)=>a.displayPrice.compareTo(b.displayPrice));break;
      case 'Price High': list.sort((a,b)=>b.displayPrice.compareTo(a.displayPrice));break;
      case 'Oldest': list.sort((a,b)=>a.createdAt.compareTo(b.createdAt));break;
      default:list.sort((a,b)=>b.updatedAt.compareTo(a.updatedAt));
    }
    return list;
  }

  @override Widget build(BuildContext context){
    final s=AppStateScope.of(context),list=_filtered(s);
    final societies=<String>{'All','B-17','FMC','Faisal Hills',...s.societies.map((e)=>e.name)}.toList();
    return Scaffold(backgroundColor:Colors.transparent,
      floatingActionButton:FloatingActionButton.extended(heroTag:'addProperty',
        onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const PropertyFormScreen())),
        icon:const Icon(Icons.add),label:const Text('Add Property')),
      body:Column(children:[
        Padding(padding:const EdgeInsets.fromLTRB(16,8,16,10),child:Column(children:[
          TextField(controller:_search,onChanged:(_)=>setState((){}),decoration:const InputDecoration(
            prefixIcon:Icon(Icons.search),hintText:'Search ID, ref no, plot, owner, block…')),
          const SizedBox(height:8),
          SingleChildScrollView(scrollDirection:Axis.horizontal,child:Row(children:[
            _filter('View',_status,const ['Active','Available','Hold','Reserved','Sold','Rented','Unavailable','Archived','All'],(v)=>setState(()=>_status=v)),
            const SizedBox(width:8),_filter('Society',_society,societies,(v)=>setState(()=>_society=v)),
            const SizedBox(width:8),_filter('Type',_type,const ['All','Residential Plot','Commercial Plot','House','Apartment','Shop','Office','Farmhouse','Other'],(v)=>setState(()=>_type=v)),
            const SizedBox(width:8),_filter('Sort',_sort,const ['Newest','Oldest','Price Low','Price High'],(v)=>setState(()=>_sort=v)),
          ])),
        ])),
        Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:Row(children:[
          Text('${list.length} records',style:const TextStyle(color:EstatePilotTheme.textSecondary,fontSize:12)),
          const Spacer(),
          Text('Active ${s.activeProperties}  •  Sold ${s.soldProperties}',style:const TextStyle(color:EstatePilotTheme.textSecondary,fontSize:12)),
        ])),
        const SizedBox(height:8),
        Expanded(child:list.isEmpty?EmptyState(icon:Icons.home_work_outlined,
          title:s.totalProperties==0?'No properties yet':'No matching properties',
          message:s.totalProperties==0?'Add your first property. EstatePilot will keep its reference, source, media, status and history for future use.':'Change search or filters to view other inventory.',
          actionLabel:s.totalProperties==0?'Add Property':null,onAction:s.totalProperties==0?()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const PropertyFormScreen())):null)
          :ListView.separated(padding:const EdgeInsets.fromLTRB(16,2,16,100),itemCount:list.length,separatorBuilder:(_,__)=>const SizedBox(height:10),itemBuilder:(context,i)=>_card(context,list[i]))),
      ]));
  }

  Widget _filter(String label,String value,List<String> values,ValueChanged<String> onChanged)=>PopupMenuButton<String>(
    initialValue:value,onSelected:onChanged,itemBuilder:(_)=>values.map((e)=>PopupMenuItem(value:e,child:Text(e))).toList(),
    child:Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:9),decoration:BoxDecoration(
      color:EstatePilotTheme.secondaryBackground,border:Border.all(color:EstatePilotTheme.divider),borderRadius:BorderRadius.circular(12)),
      child:Row(mainAxisSize:MainAxisSize.min,children:[Text('$label: $value',style:const TextStyle(fontSize:12,fontWeight:FontWeight.w700)),const SizedBox(width:5),const Icon(Icons.expand_more,size:17)])));

  Widget _card(BuildContext context,PropertyModel item){
    final String? photo=item.imagePaths.isEmpty?null:item.imagePaths.first;
    return Card(child:InkWell(borderRadius:BorderRadius.circular(18),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>PropertyDetailScreen(propertyId:item.id))),
      child:Padding(padding:const EdgeInsets.all(13),child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
        ClipRRect(borderRadius:BorderRadius.circular(14),child:Container(width:82,height:92,color:EstatePilotTheme.secondaryBackground,
          child:photo!=null&&File(photo).existsSync()?Image.file(File(photo),fit:BoxFit.cover):const Icon(Icons.home_work_outlined,color:EstatePilotTheme.gold,size:32))),
        const SizedBox(width:12),
        Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Row(children:[Expanded(child:Text('${item.propertyId} • ${item.size} ${item.unit}',style:const TextStyle(fontWeight:FontWeight.w900,fontSize:14.5))),StatusBadge(item.status)]),
          if(item.referenceNo.isNotEmpty&&item.referenceNo!=item.propertyId)Padding(padding:const EdgeInsets.only(top:3),child:Text('Ref: ${item.referenceNo}',style:const TextStyle(fontSize:11,color:EstatePilotTheme.textSecondary))),
          const SizedBox(height:5),Text(item.displayLocation,maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(color:EstatePilotTheme.textSecondary,fontSize:12)),
          const SizedBox(height:9),
          Text(formatPkr(item.displayPrice),style:const TextStyle(color:EstatePilotTheme.lightGold,fontWeight:FontWeight.w900,fontSize:16)),
          const SizedBox(height:6),
          Row(children:[Icon(Icons.source_outlined,size:14,color:EstatePilotTheme.gold),const SizedBox(width:4),Expanded(child:Text(item.source,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:11.5))),
            if(item.imagePaths.isNotEmpty)Text('${item.imagePaths.length} photos',style:const TextStyle(fontSize:10.5,color:EstatePilotTheme.textSecondary))]),
        ])),
      ]))));
  }
}
