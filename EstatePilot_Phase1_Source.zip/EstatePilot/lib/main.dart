import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'core/theme.dart';
import 'data/local_store.dart';
import 'screens/home_shell.dart';
import 'state/app_state.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
  final store = LocalStore();
  final appState = AppState(store);
  await appState.initialize();
  runApp(EstatePilotApp(state: appState));
}

class EstatePilotApp extends StatelessWidget {
  const EstatePilotApp({super.key, required this.state});
  final AppState state;

  @override
  Widget build(BuildContext context) {
    return AppStateScope(
      notifier: state,
      child: AnimatedBuilder(
        animation: state,
        builder: (context, _) {
          final mode = state.settings.themeMode == 'light' ? ThemeMode.light : ThemeMode.dark;
          return MaterialApp(
            title: 'EstatePilot',
            debugShowCheckedModeBanner: false,
            theme: EstatePilotTheme.light,
            darkTheme: EstatePilotTheme.dark,
            themeMode: mode,
            home: state.loadFailure == null
                ? const HomeShell()
                : Scaffold(
                    body: SafeArea(
                      child: Center(
                        child: Padding(
                          padding: const EdgeInsets.all(28),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.gpp_bad_outlined, size: 55, color: EstatePilotTheme.error),
                              const SizedBox(height: 16),
                              const Text('Storage could not be opened',
                                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                              const SizedBox(height: 12),
                              Text(state.loadFailure!, textAlign: TextAlign.center),
                              const SizedBox(height: 12),
                              const Text(
                                'Editing is disabled so existing CRM data is not overwritten. '
                                'Do not uninstall the app before creating a recovery copy.',
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
          );
        },
      ),
    );
  }
}
