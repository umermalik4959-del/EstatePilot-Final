import 'dart:convert';
import 'dart:io';
import '../core/native_bridge.dart';
import 'models.dart';

/// Transactional, app-private SQLite persistence through native Android.
/// Migrates old EstatePilot v1 JSON exactly once, retaining an untouched copy.
class LocalStore {
  static const _legacyName = 'estatepilot_v1.json';

  Future<EstatePilotDatabase> load() async {
    final sqlite = EstatePilotDatabase.fromJson(
      Map<String, dynamic>.from(jsonDecode(await NativeBridge.loadSnapshot()) as Map),
    );
    if (sqlite.hasBusinessData) return sqlite;
    final path = await NativeBridge.getDataPath();
    final legacy = File('$path/$_legacyName');
    if (!await legacy.exists()) return sqlite;
    final decoded = jsonDecode(await legacy.readAsString());
    if (decoded is! Map) throw const FormatException('Existing legacy data is malformed');
    final migrated = EstatePilotDatabase.fromJson(Map<String, dynamic>.from(decoded));
    if (!migrated.hasBusinessData) return sqlite;
    await save(migrated);
    // Keep an unchanged recovery copy, but do not re-import it repeatedly.
    await legacy.rename('${legacy.path}.migrated');
    return migrated;
  }

  Future<void> save(EstatePilotDatabase database) async {
    await NativeBridge.saveSnapshot(jsonEncode(database.toJson()));
  }

  Future<bool> exportBackup(EstatePilotDatabase database) async {
    final root = database.toJson();
    root['exportedAt'] = DateTime.now().toUtc().toIso8601String();
    root['format'] = 'EstatePilotBackup';
    return NativeBridge.exportBackup(const JsonEncoder.withIndent('  ').convert(root));
  }

  Future<EstatePilotDatabase?> importBackup() async {
    final content = await NativeBridge.importBackup();
    if (content == null) return null;
    final json = jsonDecode(content);
    if (json is! Map) throw const FormatException('Backup root is not an object');
    final root = Map<String, dynamic>.from(json);
    if (!root.containsKey('schemaVersion') || !root.containsKey('properties')) {
      throw const FormatException('The selected file is not an EstatePilot backup');
    }
    final version = root['schemaVersion'];
    if (version is! num || version < 1 || version > 3) {
      throw const FormatException('Unsupported EstatePilot backup version');
    }
    for (final name in const ['properties','clients','leads','followUps','activities',
      'siteVisits','deals','societies','marketRates','verifications','appSettings']) {
      if (root.containsKey(name) && root[name] is! List) {
        throw FormatException('Invalid backup section: $name');
      }
      final items = root[name] as List? ?? const [];
      final ids = <String>{};
      for (final item in items) {
        if (item is! Map || item['id'] is! String ||
            (item['id'] as String).isEmpty || !ids.add(item['id'] as String)) {
          throw FormatException('Invalid or duplicate record in $name');
        }
      }
    }
    return EstatePilotDatabase.fromJson(root);
  }
}
