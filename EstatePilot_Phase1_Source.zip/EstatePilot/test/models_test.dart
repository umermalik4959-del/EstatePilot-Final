import 'package:estatepilot/data/models.dart';
import 'package:flutter_test/flutter_test.dart';

PropertyModel sampleProperty()=>PropertyModel(
  id:'prop-1',propertyId:'EP-001',referenceNo:'REF-001',society:'B-17',block:'B',sector:'',street:'12',plotNumber:'123',
  type:'Residential Plot',size:'8',unit:'Marla',purpose:'Sale',status:'Available',
  ownerDemand:9500000,askingPrice:9400000,expectedDealPrice:9000000,minimumPrice:8800000,
  salePrice:0,commission:0,tokenAmount:0,remainingAmount:0,paymentTerms:'Cash',installmentAvailable:false,
  ownerName:'Owner',ownerPhone:'03001234567',source:'Owner Direct',sourceContact:'03001234567',sourceDetail:'Direct owner reference',
  roadWidth:'40 ft',facing:'North',locationNotes:'Near park',notes:'Negotiable',corner:true,parkFacing:false,mainRoad:false,
  possession:true,electricity:true,gas:true,water:true,sewerage:true,negotiable:true,urgentSale:false,
  imagePaths:const [],videoPaths:const [],documentPaths:const [],history:const ['created'],soldAt:null,
  createdAt:DateTime(2026,10,7),updatedAt:DateTime(2026,10,7));

void main(){
  test('property JSON round-trip preserves professional CRM fields',(){
    final restored=PropertyModel.fromJson(sampleProperty().toJson());
    expect(restored.propertyId,'EP-001');
    expect(restored.referenceNo,'REF-001');
    expect(restored.ownerDemand,9500000);
    expect(restored.expectedDealPrice,9000000);
    expect(restored.sourceDetail,'Direct owner reference');
    expect(restored.history.single,'created');
  });

  test('database JSON round-trip preserves collections and settings',(){
    final db=EstatePilotDatabase(activities:[ActivityModel(id:'act-1',title:'Test activity',subtitle:'Created during test',kind:'test',createdAt:DateTime(2026,10,7))],
      appSettings:const [AppSettingsModel(id:'APP-SETTINGS',profileName:'Umer',profilePhone:'',currency:'PKR',dateFormat:'dd MMM yyyy',defaultSociety:'B-17',defaultPropertyView:'Active',themeMode:'dark')]);
    final restored=EstatePilotDatabase.fromJson(db.toJson());
    expect(restored.activities.single.title,'Test activity');
    expect(restored.appSettings.single.themeMode,'dark');
  });
}
