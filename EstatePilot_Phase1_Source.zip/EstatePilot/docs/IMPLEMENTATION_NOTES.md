# EstatePilot v3 implementation notes

The attached original design specification is the visual source of truth.

## Brand tokens
- #101010 primary background
- #181614 secondary background
- #211D19 cards/surfaces
- #493426 warm brown
- #30231C deep brown
- #C6A06A metallic gold accent
- #D9B77E light gold
- #F5F0E8 primary off-white text
- #B8ADA1 secondary text
- #39312A borders/dividers

Blue/navy primary colors are intentionally absent from the app UI source.

## Data rules
- CRM starts without fake business records.
- Three requested society reference records are seeded and editable.
- Data writes are serialized and committed through native SQLite transactions.
- Sold records are retained and excluded from default active inventory.
- Archive is reversible and retains record history.
- Property media is copied into app-private storage.
