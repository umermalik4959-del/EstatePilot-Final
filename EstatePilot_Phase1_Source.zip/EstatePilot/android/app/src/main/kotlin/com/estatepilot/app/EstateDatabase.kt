package com.estatepilot.app

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

/**
 * App-private, transactional SQLite document store. A separate row is kept for
 * each CRM record, with unique identity and type indexes. A full app-state
 * mutation is committed in ONE transaction: power loss cannot leave half a
 * saved deal, property or lead. No business data is generated automatically.
 * Older schema versions are upgraded without DROP TABLE / data deletion.
 */
class EstateDatabase(context: Context) : SQLiteOpenHelper(
    context.applicationContext, "estatepilot.db", null, 3
) {
    private val entities = listOf(
        "properties", "clients", "leads", "followUps", "activities",
        "siteVisits", "deals", "societies", "marketRates", "verifications", "appSettings"
    )

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS crm_records (
                entity_type TEXT NOT NULL,
                record_id TEXT NOT NULL,
                json_value TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                PRIMARY KEY(entity_type, record_id)
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_crm_type_date ON crm_records(entity_type, updated_at)")
        db.execSQL("CREATE TABLE IF NOT EXISTS app_meta (meta_key TEXT PRIMARY KEY, meta_value TEXT NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Additive migration only. Never wipe a customer's CRM database.
        onCreate(db)
    }

    @Synchronized fun loadSnapshot(): String {
        val root = JSONObject()
        root.put("schemaVersion", 3)
        val db = readableDatabase
        for (entity in entities) {
            val result = JSONArray()
            db.query(
                "crm_records", arrayOf("json_value"), "entity_type=?",
                arrayOf(entity), null, null, "rowid ASC"
            ).use { cursor ->
                while (cursor.moveToNext()) result.put(JSONObject(cursor.getString(0)))
            }
            root.put(entity, result)
        }
        return root.toString()
    }

    @Synchronized fun saveSnapshot(snapshotJson: String) {
        val root = JSONObject(snapshotJson)
        require(root.optInt("schemaVersion", 0) in 1..3) {
            "Unsupported database snapshot version"
        }
        val validated = linkedMapOf<String, List<JSONObject>>()
        for (entity in entities) {
            val data = root.optJSONArray(entity) ?: JSONArray()
            val items = mutableListOf<JSONObject>()
            val ids = mutableSetOf<String>()
            for (i in 0 until data.length()) {
                val obj = data.getJSONObject(i)
                val id = obj.optString("id")
                require(id.isNotBlank() && ids.add(id)) {
                    "Invalid/duplicate identifier in $entity"
                }
                items.add(obj)
            }
            validated[entity] = items
        }
        val db = writableDatabase
        db.beginTransaction()
        try {
            for ((entity, records) in validated) {
                db.delete("crm_records", "entity_type=?", arrayOf(entity))
                for (obj in records) {
                    val values = android.content.ContentValues().apply {
                        put("entity_type", entity)
                        put("record_id", obj.getString("id"))
                        put("json_value", obj.toString())
                        put("updated_at", obj.optString("updatedAt", obj.optString("createdAt", "")))
                    }
                    check(db.insertOrThrow("crm_records", null, values) != -1L)
                }
            }
            db.execSQL(
                "INSERT OR REPLACE INTO app_meta(meta_key,meta_value) VALUES('last_saved_at',?)",
                arrayOf(System.currentTimeMillis().toString())
            )
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }
}
